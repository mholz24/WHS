function BrowserIsChrome() {
    console.log(navigator.userAgent);

    if (navigator.userAgent.indexOf("Edg") != -1) {
        return false;
    }
    else if (navigator.userAgent.indexOf("Chrome") != -1) {
        return true;
    } 
    else {
        return false;
    }
}