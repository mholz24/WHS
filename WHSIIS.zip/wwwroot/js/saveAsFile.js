﻿function saveAsFile(filename, bytesBase64) {
    console.log('123');
    debugger;
    var link = document.createElement('a');
    link.download = filename
    link.href = "data:application/octet-stream;base64," + bytesBase64
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function download() {
   var url_string = window.location.href;
   var url = new URL(url_string);
    window.open(url.origin + "/Home/Index", '_blank');
}


function SignForm(Name) {
    console.log(document.getElementById("Name").value);
    Name = document.getElementById("Name").value;
    
    if (Name === '') {
        alert('Please enter the MISID');
        return;
    } 
    var url_string = window.location.href;
    var url = new URL(url_string);
    window.open(url.origin + "/Home/SignForm?Name=" + Name, '_blank');
    isDigital = false;
}
